# simples-licenca-dashboard
Site e bot que permitem gerir licenças de plugins

Demonstração: https://youtu.be/bUXUmipaS3I
