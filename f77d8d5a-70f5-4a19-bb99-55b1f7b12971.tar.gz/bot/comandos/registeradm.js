module.exports.help = {
    name: "registeradm",
    aliases: ["registraradm"]
}    

exports.run = async (client, message, args, err) => {
if(message.member.hasPermission("ADMININSTRATOR")) {
    const Users = require('../../db/Usuarios')
const discord = require('discord.js')

let email = args[0]
if(!email) return message.reply("você deve inserir um email!!")
    let findE = await Users.findOne({
        where: {
        email: email
    }})
    if(findE) return message.channel.send(`Esse email já está cadastrado!`)
    
    function pass(length) {
        var result           = '';
        var characters       = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
        var charactersLength = characters.length;
        for ( var i = 0; i < length; i++ ) {
           result += characters.charAt(Math.floor(Math.random() * charactersLength));
        }
        return result;
     }

    let password = pass(6)
  await Users.create({
        id: message.author.id,
        email: email,
        senha: password,
      admin: 1
    })
    message.delete()
    message.author.send(new discord.MessageEmbed().setTitle(`Sucesso`).setDescription(`Foste registrado com sucesso com o email ${email} e a senha é ${password}.`).setColor(client.cor))
} else {
    message.reply("você não possue permissão para isto.")
}

}