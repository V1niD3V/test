require('dotenv').config();
const { Sequelize } = require("sequelize")

module.exports = new Sequelize("s41_database", "u41_bxjjLSI1Kp", "p@n0SIx89@H.0xi48=LbrUns", {
    host: "52.229.27.140",
    dialect: 'mysql'
})